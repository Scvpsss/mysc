from regis import *


@bot.on(events.CallbackQuery(data=b'change-vmess-qouta'))
async def ganti_ip(event):
    async def ganti_ip_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**User Yang Mau Diganti:**')
            user = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user.raw_text.strip()

        async with bot.conversation(chat) as pw_conv:
            await event.respond("**Limit Nya Sayang:**")
            pw = await pw_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw = pw.raw_text.strip()

        await event.edit("Processing.")
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(3)
        await event.edit("`Processing Crate Premium Account`")
        time.sleep(1)
        await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(2)
        await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(3)
        await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(2)
        await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(0)
        await event.edit("`Processing... 100%\n█████████████████████████ `")
        time.sleep(1)
        await event.edit("`Wait.. Setting up an Account`")

        cmd = f'printf "%s\n" "{user}" "{pw}" | change-vmess-qouta'
        try:
            subprocess.run(cmd, shell=True, check=True, capture_output=True, text=True)
            await event.respond(f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
**☘️ SUKSES GANTI QOUTA VMESS ☘️**
**━━━━━━━━━━━━━━━━━━━━━━━**
**» User :** `{user}`
**» Quota Baru :** `{pw} GB`
****» THANK YOU**
**» 🤖@Burhanssh**
""")
        except subprocess.CalledProcessError as e:
            await event.respond(f"Error: {e.output}")

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await ganti_ip_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)