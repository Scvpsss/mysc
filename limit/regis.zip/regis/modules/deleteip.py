import subprocess
from regis import *

@bot.on(events.CallbackQuery(data=b'deleteip'))
async def deleteipp(event):
    async def deleteipp_(event):
        async with bot.conversation(chat) as pw_conv:
            await event.respond("**Input IP VPS:**")
            try:
                pw_msg = await pw_conv.wait_event(events.NewMessage(incoming=True, from_users=chat), timeout=60)  # Timeout set to 60 seconds
                pw = pw_msg.raw_text
            except asyncio.TimeoutError:
                await event.respond("**Timeout. Please try again.**")
                return
        cmd = f'printf "%s\n" "{pw}" | bash /root/regis/shell/bot-deleteip'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError:
            await event.respond("**Not Exist**")
        else:
            msg = f"""```{a}```
**» 🤖@ZECTSTORE**"""
            await event.respond(msg)
            
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await deleteipp_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)